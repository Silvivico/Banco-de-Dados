using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class MudarDeSala : MonoBehaviour
{

    public string sena;
    public void BoraDeNext( )
    {
        SceneManager.LoadScene(sena);
    }
}
