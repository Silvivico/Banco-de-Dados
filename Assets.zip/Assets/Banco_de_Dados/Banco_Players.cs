using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.Data;
using Mono.Data.Sqlite;
using UnityEditor.Experimental.GraphView;
using Unity.VisualScripting;

public class Banco_Players : MonoBehaviour
{

    private IDbConnection conec;
    private IDbCommand command;
    private IDataReader reader;

    private string stringConexao = "URI=file:Assets/Banco_de_Dados/StreamingAssets/meuBanco.db";
    private bool conectar()
    {

        try
        {

            conec = new SqliteConnection(stringConexao);
            conec.Open();
            command = conec.CreateCommand();

            //cria a tabela
            command.CommandText = "PRAGMA foreign_keys = ON;  CREATE TABLE IF NOT EXISTS USUARIOS" +
                "(ID INTEGER PRIMARY KEY AUTOINCREMENT, NOME VARCHAR(50), PONTOS INTEGER);";

            //executa command text
            command.ExecuteNonQuery();

            return true;
        }
        catch (System.Exception ex)
        {
            print(ex.Message);

            return false;
        }
    }


    public bool inserir(string nome)
    {
        try
        {
            conectar();

            //command.CommandText = "INSERT INTO USUARIOS(NOME) VALUES ($nome);";
            //command.Parameters.Add(nome);

            command = conec.CreateCommand();
            command.CommandText = "INSERT INTO USUARIOS(NOME) VALUES ('" + nome + " ');";

            command.ExecuteNonQuery();

            return true;
        }

        catch (System.Exception ex)
        {
            print(ex.Message);


            return false;
        }
        finally
        {
            conec.Close();
        }
    }

    public bool inserirScalar(string nome)
    {
        try
        {
            conectar();
            int idInserido;
            string comandoSql = "INSERT  INTO USUARIOS(NOME) VALUES ('" + nome + "');" + "SELECT CAST(scope_identity() AS int)";

            command.CommandText = comandoSql;
            idInserido = (int)command.ExecuteScalar();

            return true;
        }
        catch (System.Exception ex)
        {

            print(ex.Message);
            return false;

        }
        finally
        {
            conec.Close();
        }
    }

    public bool remover(int id)
    {
        try
        {
            conectar();
            command.CommandText = "delete from usuarios where id = " + id + ";";
            command.ExecuteNonQuery();
            return true;
        }
        catch (System.Exception ex)
        {
            print(ex.Message);
            return false;
        }
    }

    public bool alterar(int id, string nome)
    {
        try
        {
            conectar();
            command.CommandText = "update usuarios set nome = '" + nome + "' where id = " + id + ";";

            command.ExecuteNonQuery();
            return true;
        }
        catch (System.Exception ex)
        {
            print(ex.Message);
            return false;
        }
        finally
        {
            conec.Close();
        }

    }

    public bool consultar()
    {
        try
        {
            conectar();

            string comandoSql = "SELECT * FROM USUARIOS;";
            command.CommandText = comandoSql;
            reader = command.ExecuteReader();

            int cont = 0;

            while (reader.Read())
            {

                print("ID: " + reader.GetInt32(0));
                print("NOME: " + reader.GetString(1));
                print("PONTOS " + reader.GetInt32(0));

                cont++;
            }
            print("Total de Registros: " + cont);

            return true;
        }
        catch (System.Exception ex)
        {
            print(ex.Message);
            return false;
        }
        finally
        {
            conec.Close();
        }
    }

    public bool inserirPontos(int id)
    {
        Pontos pontos = new Pontos();


        try
        {
            command.CommandText = "UPDATE USUARIOS SET PONTOS = '" + pontos.pontos + "' WHERE ID = " + id + ";";

            return true;
        }
        catch (System.Exception ex)
        {
            print(ex.Message);
            return false;
        }

    }



}
