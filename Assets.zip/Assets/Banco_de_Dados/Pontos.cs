using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Pontos : MonoBehaviour
{
   
    public float time = 10f;
    public string sala;
    public int pontos;

   
    public void AddPontos()
    {

        GlobalVars.pontos++;

    }

    public void ZerarPontos()
    {
        GlobalVars.pontos = 0; 
    }

    public void TerminouJogo(string cena)
    {
        SceneManager.LoadScene(cena);
    }

    private void Update()
    {
       time -= Time.deltaTime;

        if (time <= 0)
        {
            TerminouJogo(sala);
        }
        Debug.Log(GlobalVars.pontos);  
    }


}
