using Palmmedia.ReportGenerator.Core.Parser.Analysis;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour
{
    public TMP_InputField id;
    public TMP_InputField name;
    


    public void Inserir()
    {
        SQL banco = new SQL();
        MudarDeSala room = new MudarDeSala();

        banco.inserir(name.text);
        room.BoraDeNext();

    }
    public void Atualizar()
    {
        SQL banco = new SQL();

        banco.alterar(int.Parse(id.text), name.text);
    }
    public void Excluir()
    {
        SQL banco = new SQL();

        banco.remover(int.Parse(id.text));
    }

    public void Consultar()
    {
        SQL banco = new SQL();

        banco.consultar();
    }

    public void NewGame(string cena )
    {
        Pontos pontos = new Pontos();
        SceneManager.LoadScene(cena);
        pontos.ZerarPontos();
        
    }

    private void Update()
    {

        Debug.Log(GlobalVars.pontos);
    }
















    
 

}
